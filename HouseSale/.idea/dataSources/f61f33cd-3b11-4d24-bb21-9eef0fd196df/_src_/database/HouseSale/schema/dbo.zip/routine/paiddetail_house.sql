--收款明细表
create proc [dbo].[paiddetail_house]
	@projectid varchar(10),
	@termtype varchar(20),
	@salestate varchar(30),
	@custname varchar(20),
	@signdate1 varchar(20),
	@signdate2 varchar(20),
	@paidtype varchar(10)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field11,field12,field13,field14,field15,field16,field17,field18,field41) '
	set @sql = @sql +' select c.custname,h.hoursename,tt.ticketno,tt.tickettype,f.ticketflow,f.paidtypeid,f.paidsortid,f.warrant,f.inbank,f.bankaccount,f.outbank,h.salearea,b.totalmoney,b.firstmoney,b.bankmoney,f.paidmoney,f.paidperson,f.oprtype,f.paidtime from finance f '
	set @sql = @sql +' left outer join buyhourse b on f.buyid=b.buyid left outer join customerinfo c on b.custid=c.custid left outer join hourseinfo h on h.hourseid=b.hourseid '
	set @sql = @sql +' left outer join terminfo t on t.termid=h.termid left outer join projectinfo p on t.projectid=p.projectid left outer join ticket tt on tt.ticketid=f.ticketno '
	set @sql = @sql +' where f.invalid=''有效'' and b.invalid=''有效'' '
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @salestate <>'' 
	begin
		set @sql = @sql + ' and h.salestate = '''+@salestate +''''
	end
	if @paidtype<>''
	begin
		set @sql = @sql + ' and f.oprtype='''+@paidtype +''''
	end
	if @custname <>'' 
	begin
		set @sql = @sql + ' and c.custname like ''%'+@custname +'%'''
	end
	if @signdate1 <>'' and @signdate2 <>''
	begin
		set @sql = @sql + ' and f.paidtime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end	
	set @sql = @sql + ' order by c.custid,b.buyid,f.financeid '
	exec sp_executesql @sql
	update reptable set field21=field16
	insert into reptable(field1,field16) select '合计',sum(field21) from reptable
GO
