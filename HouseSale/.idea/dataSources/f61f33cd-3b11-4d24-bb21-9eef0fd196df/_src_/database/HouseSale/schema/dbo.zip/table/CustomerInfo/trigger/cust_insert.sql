CREATE TRIGGER [dbo].[cust_insert]
ON [dbo].[CustomerInfo]
AFTER INSERT
AS

	declare @custid int 
	declare @salePercent varchar(10) 
	declare @chance varchar(20)
	declare @eventtypeid varchar(30)
	select @custid=custid,@salePercent=salePercent,@chance=chance,@eventtypeid=eventtypeid from inserted
	insert into CustEvent values(@custid,@salePercent,@chance,@eventtypeid,getdate(),'')

GO
