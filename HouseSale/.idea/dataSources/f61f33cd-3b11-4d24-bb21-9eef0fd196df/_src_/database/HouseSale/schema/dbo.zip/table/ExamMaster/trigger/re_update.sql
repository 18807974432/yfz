CREATE TRIGGER [dbo].[re_update]
ON [dbo].[ExamMaster]
AFTER INSERT, UPDATE
AS

	declare  @cnt int 
	declare @researchid int 
	select @researchid=reseachid from inserted
	select @cnt = count(examid) from exammaster where reseachid=@researchid
	update researchExam set examCount=@cnt where  reseachid=@researchid

GO
