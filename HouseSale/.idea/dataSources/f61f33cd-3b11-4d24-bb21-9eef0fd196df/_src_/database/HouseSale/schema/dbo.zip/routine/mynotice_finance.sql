--我的代办任务
create proc [dbo].[mynotice_finance]
	@saleperson varchar(20)
as
	truncate table reptable
	insert into reptable(field1,field2,field3,field4,field41) 
	select c.custname,h.hoursename,b.processname,w.planmoney,w.starttime from buyhourse b left outer join workprocess w  on w.processid=b.processid 
	left outer join customerinfo c on b.custid=c.custid 
	left outer join hourseinfo h on b.hourseid=h.hourseid 
	where w.status='未完成' and b.salePerson=@saleperson
	order by b.custid,b.hourseid
GO
