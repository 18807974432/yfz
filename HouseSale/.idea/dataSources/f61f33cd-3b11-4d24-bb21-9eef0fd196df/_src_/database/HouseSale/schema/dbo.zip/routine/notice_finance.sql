create proc [dbo].[notice_finance]
	@saleperson varchar(20)
as
	declare @sql nvarchar(2000)
	truncate table reptable
	set @sql = ' insert into reptable(field1,field2,field3,field21,field22,field23,field24,field41) '
	set @sql = @sql + ' select c.custname,h.hoursename,b.processname,w.planmoney,b.totalmoney,b.firstmoney,b.bankmoney,w.starttime from buyhourse b left outer join workprocess w  on w.processid=b.processid '
	set @sql = @sql + ' left outer join customerinfo c on b.custid=c.custid '
	set @sql = @sql + ' left outer join hourseinfo h on b.hourseid=h.hourseid '
	set @sql = @sql + ' where w.planmoney>0 and w.status=''未完成'' '
	if @saleperson <>''
	begin
		set @sql = @sql + ' and b.salePerson='''+@saleperson + ''''
	end
	set @sql = @sql + ' order by b.custid,b.hourseid '
	exec sp_executesql @sql
	update reptable set field4=field21,field5=field22,field6=field23,field7=field24
	insert into reptable(field1,field4)
	select '合计',sum(field21) from reptable
GO
