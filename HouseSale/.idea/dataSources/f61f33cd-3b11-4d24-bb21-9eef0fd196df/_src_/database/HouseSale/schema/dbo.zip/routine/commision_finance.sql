--佣金统计表
create proc [dbo].[commision_finance]
	@saleperson varchar(20),
	@custname varchar(20),
	@oprtype varchar(20),
	@signdate1 varchar(20),
	@signdate2 varchar(20)
as
	declare @sql nvarchar(2000)
	truncate table reptable
	if @oprtype='1'
	begin
		set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field8,field41) '
		set @sql = @sql +' select b.saleperson,h.hoursename,c.custname,b.totalMoney,h.commisionPercent,h.commisionmoney,h.commisionpaid,h.commisionmoney-h.commisionpaid,b.signtime from buyhourse b  '
		set @sql = @sql +' left outer join hourseinfo h on h.hourseid=b.hourseid left outer join customerinfo c on c.custid=b.custid '
		set @sql = @sql +' where b.invalid=''有效'' '
		if @saleperson<>''
		begin
			set @sql = @sql +' and b.saleperson='''+@saleperson +''' '
		end
		if @custname<>''
		begin
			set @sql = @sql +' and c.custname='''+@custname +''' '
		end
		if @signdate1<>'' and @signdate2<>''
		begin
			set @sql = @sql +' and b.signtime between '''+ @signdate1 + ''' and ''' + @signdate2 +''''
		end
		set @sql = @sql +' order by b.saleperson,b.buyid '
		exec sp_executesql @sql
		update reptable set field21=field6,field22=field7,field23=field8
		insert into reptable(field1,field6,field7,field8) select '总计',sum(field21),sum(field22),sum(field23) from reptable
	end
	if @oprtype='2'
	begin
		set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field41) '
		set @sql = @sql +' select b.saleperson,h.hoursename,c.custname,cc.paidmoney,h.commisionmoney,cc.paidtime from commmision cc '
		set @sql = @sql +' left outer join buyhourse b on cc.buyid=b.buyid left outer join hourseinfo h on h.hourseid=b.hourseid '
		set @sql = @sql +' left outer join customerinfo c on c.custid=b.custid	where b.invalid=''有效'' and cc.invalid=''有效'' '
		if @saleperson<>''
		begin
			set @sql = @sql +' and b.saleperson='''+@saleperson +''' '
		end
		if @custname<>''
		begin
			set @sql = @sql +' and c.custname='''+@custname +''' '
		end
		if @signdate1<>'' and @signdate2<>''
		begin
			set @sql = @sql +' and cc.paidtime between '''+ @signdate1 + ''' and ''' + @signdate2 +''''
		end
		set @sql = @sql +' order by b.saleperson,b.buyid '
		exec sp_executesql @sql
		update reptable set field21=field4
		insert into reptable(field1,field4)
		select '总计',sum(field21) from reptable
	end
GO
