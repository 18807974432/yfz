create proc [dbo].[bank_finance]
	@projectid varchar(10),
	@termtype varchar(20),
	@salestate varchar(30),
	@custname varchar(20),
	@signdate1 varchar(20),
	@signdate2 varchar(20),
	@isbankmoney varchar(10) --银行是否到账
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field11,field41) '
	set @sql = @sql +' select c.custname,h.hoursename,h.salestate,b.salePerson,b.bankmoney,b.bankAccrual,b.bankYear,b.bankPercent,b.unitPrice,b.totalMoney,b.firstmoney,b.bankTime from buyhourse b '
	set @sql = @sql +' left outer join customerinfo c on b.custid=c.custid '
	set @sql = @sql +' left outer join hourseinfo h on b.hourseid=h.hourseid '
	set @sql = @sql +' left outer join terminfo t on t.termid=h.termid '
	set @sql = @sql +' where b.bankid <>'''' and b.bankmoney >0 and b.invalid=''有效'''
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @salestate <>'' 
	begin
		set @sql = @sql + ' and h.salestate = '''+@salestate +''''
	end
	if @isbankmoney='已到账'
	begin
		set @sql = @sql + ' and b.bankTime is not null '
	end
	else
	begin
		set @sql = @sql + ' and b.bankTime is null '
	end
	if @custname <>'' 
	begin
		set @sql = @sql + ' and c.custname like ''%'+@custname +'%'''
	end
	if @signdate1 <>'' and @signdate2 <>'' and @isbankmoney='已到账'
	begin
		set @sql = @sql + ' and b.bankTime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end	
	set @sql = @sql + ' order by c.custid,b.buyid '
	exec sp_executesql @sql
	update reptable set field21=field5
	insert into reptable(field1,field5) select '合计',sum(field21) from reptable
GO
