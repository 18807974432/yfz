--回款统计表
create proc [dbo].[paidtj_finance]
	@oprtype varchar(20),
	@signdate1 varchar(20),
	@signdate2 varchar(20)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4) '
	set @sql =@sql + ' select oprtype,paidtypeid,paidsortid,sum(paidmoney) from finance '
	set @sql =@sql + ' where invalid=''有效'' '
	if @oprtype <>'' 
	begin
		set @sql = @sql + ' and oprtype='''+@oprtype +''''
	end
	if @signdate1 <>'' and @signdate2 <>''
	begin
		set @sql = @sql + ' and paidTime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end	
	set @sql = @sql + ' group by oprtype,paidtypeid,paidsortid '
	exec sp_executesql @sql
	update reptable set field21=field4
	insert into reptable(field1,field4) select '合计',sum(field21) from reptable
GO
