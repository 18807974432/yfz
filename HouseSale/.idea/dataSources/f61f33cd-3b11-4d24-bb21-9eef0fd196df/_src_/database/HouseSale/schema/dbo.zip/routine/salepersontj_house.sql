--销售员汇总表
create proc [dbo].[salepersontj_house]
	@projectid varchar(10),
	@termtype varchar(20),
	@salestate varchar(30),
	@saleperson varchar(20),
	@signdate1 varchar(20),
	@signdate2 varchar(20)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6) '
	set @sql = @sql + ' select b.saleperson,count(b.hourseid),sum(totalmoney),sum(firstmoney),sum(bankmoney),sum(h.salearea) '
	set @sql = @sql + ' from buyhourse b left outer join hourseinfo h on b.hourseid=h.hourseid left outer join terminfo t on h.termid=t.termid '
	set @sql = @sql + ' left outer join projectinfo p on t.projectid=p.projectid where oprtype<>''退房'' and invalid=''有效'' '
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @salestate <>'' 
	begin
		set @sql = @sql + ' and h.salestate = '''+@salestate +''''
	end
	if @saleperson <>'' 
	begin
		set @sql = @sql + ' and b.saleperson = '''+@saleperson +''''
	end
	if @signdate1 <>'' and @signdate2 <>''
	begin
		set @sql = @sql + ' and b.buyTime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end	
	set @sql = @sql + ' group by b.saleperson '
	exec sp_executesql @sql
	update reptable set field21=field2,field22=field3,field23=field4,field24=field5,field25=field6
	insert into reptable(field1,field2,field3,field4,field5,field6) select '合计',sum(field21),sum(field22),sum(field23),sum(field24),sum(field25) from reptable
GO
