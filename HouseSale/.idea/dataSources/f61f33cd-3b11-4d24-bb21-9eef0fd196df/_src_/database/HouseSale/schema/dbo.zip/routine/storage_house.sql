create proc [dbo].[storage_house]
	@projectid varchar(10),
	@termtype varchar(20),
	@salestate varchar(30)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7) '
	set @sql = @sql + ' select projectname,termname,h.termtype,salestate,count(hourseid) housecount,sum(h.salearea) salearea,sum(h.totalPrice) totalPrice  from hourseinfo h '
	set @sql = @sql + ' left outer join terminfo t on h.termid=t.termid left outer join projectinfo p on t.projectid=p.projectid '
	set @sql = @sql + ' where salestate not in(''签约'',''订购'') '
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @salestate <>'' 
	begin
		set @sql = @sql + ' and h.salestate = '''+@salestate +''''
	end
	set @sql = @sql + ' group by projectname,termname,h.termtype,salestate '
	exec sp_executesql @sql
	update reptable set field21=field5,field22=field6,field23=field7
	insert into reptable(field1,field5,field6,field7) select '合计',sum(field21),sum(field22),sum(field23) from reptable
GO
