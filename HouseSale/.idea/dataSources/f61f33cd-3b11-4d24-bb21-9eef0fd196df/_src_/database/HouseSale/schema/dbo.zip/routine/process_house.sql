create proc [dbo].[process_house]

	@projectid varchar(10),
	@termtype varchar(20),
	@housename varchar(30),
	@signdate1 varchar(20),
	@signdate2 varchar(20)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field11,field21,field22,field23,field24,field25,field41,field42,field43) '
	set @sql = @sql +' select c.custname,c.primarytel,h.hoursename,h.termtype,b.saleperson,psname,processname,b.bankid,flowname,w.status,b.oprtype,b.firstmoney,b.unitPrice,b.totalMoney,h.salearea,b.bankmoney,b.buytime,w.starttime,w.finishtime from WorkProcess w '
	set @sql = @sql +' left outer join BuyHourse b on b.buyid=w.buyId left outer join CustomerInfo c on w.custid=c.custId left outer join HourseInfo h  on w.hourseid=h.hourseId '
	set @sql = @sql +' left outer join TermInfo t on t.termid=h.termid left outer join paidscheme p on b.psid=p.psid '
	set @sql = @sql + ' where b.invalid=''有效'''
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @housename <>'' 
	begin
		set @sql = @sql + ' and h.hoursename = '''+@housename +''''
	end
	if @signdate1 <>'' and @signdate2 <>''
	begin
		set @sql = @sql + ' and b.buyTime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end
	set @sql = @sql + ' order by w.buyid,w.processid'
	exec sp_executesql @sql
GO
