CREATE proc [dbo].[order_house]

	@projectid varchar(10),
	@termtype varchar(20),
	@custname varchar(30)
as

truncate table reptable
declare @sql nvarchar(2000)
set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field21,field22,field23,field24,field25,field26,field27,field28,field29,field30,field31,field32,field41,field42,field43,field44,field45) '
set @sql = @sql + ' select c.custname,c.primarytel,h.hoursename,h.termtype,b.saleperson,psname,processname,b.firstmoney,b.unitPrice,b.totalMoney,h.salearea,e.paidmoney, '
set @sql = @sql + ' isnull((select sum(paidmoney) from finance f where f.buyid=b.buyid),0) paidfirst,signUnitPrice,fitmentUnitPrice,signTotalPrice,fitmentTotalPrice,fitmentFirstPrice,fitmentLastPrice, '
set @sql = @sql + ' b.buytime,b.signtime,b.banktime,e.paidtime,(select startTime from workprocess w where w.buyid=b.buyid and flowNode=''签约'') startTime '
set @sql = @sql + ' from buyhourse b left outer join hourseinfo h on b.hourseid=h.hourseid left outer join customerinfo c on b.custid=c.custid '
set @sql = @sql + ' left outer join terminfo t on h.termid=t.termid left outer join EarnestMoney e on b.buyid=e.buyid left outer join paidscheme p on b.psid=p.psid '
set @sql = @sql + ' where e.invalid=''有效'' and b.invalid=''有效'' and b.oprtype<>''退房'' and h.salestate=''认购'''
if @projectid <>'0' 
begin
	set @sql = @sql + ' and t.projectId='+@projectid
end
if @termtype <>'' 
begin
	set @sql = @sql + ' and h.termtype='''+@termtype +''''
end
if @custname <>'' 
begin
	set @sql = @sql + ' and c.custname like ''%'+@custname +'%'''
end
set @sql = @sql + ' order by c.custname,b.buytime'
exec sp_executesql @sql
GO
