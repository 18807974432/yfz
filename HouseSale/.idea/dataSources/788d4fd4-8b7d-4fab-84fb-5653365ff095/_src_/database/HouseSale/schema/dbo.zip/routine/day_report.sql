create proc [dbo].[day_report]
	@years varchar(20),
	@begindate varchar(20),
	@enddate varchar(20)
as
	declare @cnt int
	declare @eventtypeid varchar(30)
	declare @projectname varchar(30)
	declare @termtype varchar(30)
	declare @salearea decimal(18,3)
	declare @totalmoney decimal(18,3)
	declare @salestate varchar(10)
	declare @startyear varchar(20)
	declare @endyear varchar(20)
	declare @sql nvarchar(2000)
	set @startyear=@years + '-01-01 00:00:00'
	set @endyear=@years + '-12-31 23:59:59'
	truncate table reptable
	insert into reptable(field1,field2,field3,field4)
	select eventtypeid,0,count(custid),1 from customerinfo group by eventtypeid
	declare cur cursor for select eventtypeid,count(custid) from customerinfo c where signdate between @begindate and @enddate group by eventtypeid
	open cur
	fetch next from cur into @eventtypeid,@cnt
	while @@fetch_status=0
	begin
		update reptable set field2= @cnt where field1=@eventtypeid
		fetch next from cur into @eventtypeid,@cnt
	end
	close cur
	deallocate cur
	insert into reptable(field1,field2,field3,field4,field22)
	select p.projectname,h.termtype,salestate,2,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效'
	group by p.projectname,h.termtype,salestate
	update reptable set field3='退房' where field4='2' and field3='可售'

	declare cur cursor for
	select p.projectname,h.termtype,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效' and b.oprtype='退房'
	group by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt
	while @@fetch_status=0
	begin
		update reptable set field22=@cnt where field1=@projectname and field2=@termtype and field3='退房'
		fetch next from cur into @projectname,@termtype,@cnt
	end
	close cur
	deallocate cur 
	declare cur cursor for
	select p.projectname,h.termtype,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效' and b.oprtype='退房' and (b.buytime between @begindate and @enddate or b.signtime between @begindate and @enddate)
	group by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt
	while @@fetch_status=0
	begin
		update reptable set field21=@cnt where field1=@projectname and field2=@termtype and field3='退房'
		fetch next from cur into @projectname,@termtype,@cnt
	end
	close cur
	deallocate cur 
	declare cur cursor for
	select p.projectname,h.termtype,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效' and b.oprtype<>'退房' and signtime is null
	group by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt
	while @@fetch_status=0
	begin
		update reptable set field22=@cnt where field1=@projectname and field2=@termtype and field3='认购'
		fetch next from cur into @projectname,@termtype,@cnt
	end
	close cur
	deallocate cur 
	declare cur cursor for
	select p.projectname,h.termtype,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效' and b.oprtype<>'退房' and b.buytime between @begindate and @enddate and signtime is null
	group by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt
	while @@fetch_status=0
	begin
		update reptable set field21=@cnt where field1=@projectname and field2=@termtype and field3='认购'
		fetch next from cur into @projectname,@termtype,@cnt
	end
	close cur
	deallocate cur 
	declare cur cursor for
	select p.projectname,h.termtype,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效' and b.oprtype<>'退房' and signtime is not null
	group by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt
	while @@fetch_status=0
	begin
		update reptable set field22=@cnt where field1=@projectname and field2=@termtype and field3='签约'
		fetch next from cur into @projectname,@termtype,@cnt
	end
	close cur
	deallocate cur 
	declare cur cursor for
	select p.projectname,h.termtype,count(buyid) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where b.invalid='有效' and b.oprtype<>'退房' and signtime between @begindate and @enddate
	group by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt
	while @@fetch_status=0
	begin
		update reptable set field21=@cnt where field1=@projectname and field2=@termtype and field3='签约'
		fetch next from cur into @projectname,@termtype,@cnt
	end
	close cur
	deallocate cur 

	insert into reptable(field3,field4)
	select sum(paidmoney),3 from finance where invalid='有效' and paidtime between @startyear and @endyear
	select @cnt=max(repid) from reptable
	update reptable set field2=isnull((select sum(paidmoney) from finance where invalid='有效' and paidtypeid='银行放款' and paidtime between @begindate and @enddate),0) where repid=@cnt
	update reptable set field1=isnull((select sum(paidmoney) from finance where invalid='有效' and paidtypeid<>'银行放款' and paidtime between @begindate and @enddate),0) where repid=@cnt
	update reptable set field5=isnull((select sum(paidmoney) from earnestmoney where status='收取' and invalid='有效' and paidtime between @begindate and @enddate),0) where repid=@cnt

	insert into reptable(field1,field2,field4,field21,field22,field23,field24,field25,field26,field27,field28,field29)
	select p.projectname,h.termtype,4,0,0,0,0,0,0,count(hourseid),sum(h.salearea),sum(h.totalprice) from hourseinfo h  
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	group by p.projectname,h.termtype
	order by p.projectname,h.termtype
	declare cur cursor for
	select p.projectname,h.termtype,count(h.hourseid),sum(h.salearea),sum(h.totalprice) from buyhourse b
	left outer join hourseinfo h on b.hourseid=h.hourseid
	left outer join terminfo t on h.termid=t.termid
	left outer join projectinfo p on p.projectid=t.projectid
	where h.salestate ='签约' and b.signtime between @startyear and @endyear
	group by p.projectname,h.termtype
	order by p.projectname,h.termtype
	open cur
	fetch next from cur into @projectname,@termtype,@cnt,@salearea,@totalmoney
	while @@fetch_status=0
	begin
		update reptable set field21=@cnt,field22=@salearea,field23=@totalmoney,field24=field27-@cnt,field25=field28-@salearea,field26=field29-@totalmoney where field1=@projectname and field2=@termtype and field4='4'
		fetch next from cur into @projectname,@termtype,@cnt,@salearea,@totalmoney
	end
	close cur
	deallocate cur
	update reptable set field11=field21,field12=field22,field13=field23,field14=field24,field15=field25,field16=field26,field17=field27,field18=field28,field19=field29
	insert into reptable(field1,field4,field11,field12,field13,field14,field15,field16,field17,field18,field19)
	select '总计',4,sum(field21),sum(field22),sum(field23),sum(field24),sum(field25),sum(field26),sum(field27),sum(field28),sum(field29) from reptable where field4='4'
GO
