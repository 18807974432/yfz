create proc [dbo].[change_house]
	@projectid varchar(10),
	@termtype varchar(20),
	@custname varchar(30),
	@saleState varchar(20),
	@signdate1 varchar(20),
	@signdate2 varchar(20)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field8,field9,field10,field21,field22,field23,field24,field25,field26,field27,field28,field41,field42,field43,field44) '
	set @sql = @sql + 'select c.custname,c.primarytel,h.hoursename,h.termtype,b.saleperson,p.psname,h1.hoursename hoursename1,h1.termtype termtype1,'
	set @sql = @sql + 'his.saleperson saleperson1,p1.psname psname1,b.firstmoney,b.unitPrice,b.totalMoney,h.salearea,his.firstmoney firstmoney1,'
	set @sql = @sql + 'his.unitPrice unitPrice1,his.totalMoney totalMoney1,h1.salearea salearea1,b.buytime,b.signtime,his.buytime buytime1,his.signtime signtime1 '
	set @sql = @sql + 'from buyhourse b left outer join historyhouse his on b.buyid=his.buyid left outer join hourseinfo h on b.hourseid=h.hourseid '
	set @sql = @sql + 'left outer join customerinfo c on b.custid=c.custid left outer join terminfo t on h.termid=t.termid '
	set @sql = @sql + 'left outer join paidscheme p on b.psid=p.psid left outer join hourseinfo h1 on his.hourseid=h1.hourseid '
	set @sql = @sql + 'left outer join paidscheme p1 on his.psid=p1.psid where  b.invalid=''有效'' and b.oprtype=''换房'''
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @custname <>'' 
	begin
		set @sql = @sql + ' and c.custname like ''%'+@custname +'%'''
	end
	if @saleState <>''
	begin
		set @sql = @sql + ' and h.saleState='''+@saleState +''''
	end
	if @signdate1 <>'' and @signdate2 <>''
	begin
		set @sql = @sql + ' and b.buytime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end
	set @sql = @sql + ' order by c.custname,b.buytime'
	select @sql
	exec sp_executesql @sql
GO
