CREATE TRIGGER [dbo].[add_flow]
ON [dbo].[BuyHourse]
AFTER INSERT
AS
	declare @buyid int
	declare @custid int
	declare @houseid int
	declare @buyTime datetime
	declare @psid int
	declare @day int
	declare @orderid int
	declare @flowname varchar(50)
	declare @userid varchar(20)
	declare @processid int
	declare @custstate varchar(20)
	declare @unitPrice decimal(18,3)
	declare @totalPrice decimal(18,3)
	declare @saleperson varchar(20)
	declare @custname varchar(20)
	declare @flowNode varchar(20)
	select @buyid=buyid,@custid=custid,@houseid=hourseid,@psid=psid,@unitPrice=unitPrice,@totalPrice=totalMoney,@buyTime=buyTime,@userid=userid,@saleperson=saleperson from inserted
	declare cur cursor for select flowname,finishdays,orderid,flowNode from SchemeFlow where psid=@psid order by orderid
	open cur
	fetch next from cur into @flowname,@day ,@orderid,@flowNode
	if(@@FETCH_STATUS=0)
	begin
		insert into WorkProcess values(@buyid,@custid,@houseid,@flowname,@flowNode,dateadd(day,@day,@buyTime),NULL,0,0,@orderid,'未完成',@userid,getdate())
		select @processid=max(processid) from WorkProcess
		update buyhourse set processid=@processid,processname=@flowname where buyid=@buyid
		update hourseinfo set saleState='认购',unitPrice=@unitPrice,totalPrice=@totalPrice,custid=@custid,saleTime=@buyTime,commisionMoney=@totalPrice*commisionPercent where hourseId=@houseid
		select @custstate=custstate,@custname=custname from customerinfo where custId=@custid
		if(@custstate<>'签约客户')
		begin
			update customerinfo set custstate='认购客户',saleperson=@saleperson where custId=@custid
		end	
		insert into houseEvent values(@houseid,'认购','客户'+@custname+'正式认购该房产',null,@saleperson,getdate(),'无',0);
	end
	fetch next from cur into @flowname,@day ,@orderid,@flowNode
	while(@@fetch_status=0)
	begin
		select  @buyTime=startTime from WorkProcess where processid =(select max(processid) from WorkProcess where custid=@custid and hourseid=@houseid)
		insert into WorkProcess values(@buyid,@custid,@houseid,@flowname,@flowNode,dateadd(day,@day,@buyTime),NULL,0,0,@orderid,'未完成',@userid,getdate())
		fetch next from cur into @flowname,@day ,@orderid,@flowNode
	end
	close cur
	deallocate cur

GO
