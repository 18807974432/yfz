--销售汇总表
create proc [dbo].[saletj_house]
	@projectid varchar(10),
	@termtype varchar(20),
	@salestate varchar(30),
	@signdate1 varchar(20),
	@signdate2 varchar(20)
as
	truncate table reptable
	declare @sql nvarchar(2000)
	set @sql = 'insert into reptable(field1,field2,field3,field4,field5,field6,field7,field8,field9) '
	set @sql = @sql + ' select p.projectname,t.termname,h.termtype,h.salestate,count(b.hourseid),sum(totalmoney),sum(firstmoney),sum(bankmoney),sum(h.salearea) from buyhourse b '
	set @sql = @sql + ' left outer join hourseinfo h on b.hourseid=h.hourseid left outer join terminfo t on h.termid=t.termid '
	set @sql = @sql + ' left outer join projectinfo p on t.projectid=p.projectid where oprtype<>''退房'' and invalid=''有效'''
	if @projectid <>'0' 
	begin
		set @sql = @sql + ' and t.projectId='+@projectid
	end
	if @termtype <>'' 
	begin
		set @sql = @sql + ' and h.termtype='''+@termtype +''''
	end
	if @salestate <>'' 
	begin
		set @sql = @sql + ' and h.salestate = '''+@salestate +''''
	end
	if @signdate1 <>'' and @signdate2 <>''
	begin
		set @sql = @sql + ' and b.buyTime between '''+@signdate1 +''' and ''' + @signdate2 +''''
	end	
	set @sql = @sql + ' group by p.projectname,t.termname,h.termtype,h.salestate '
	exec sp_executesql @sql
	update reptable set field21=field5,field22=field6,field23=field7,field24=field8,field25=field9
	insert into reptable(field1,field5,field6,field7,field8,field9) select '合计',sum(field21),sum(field22),sum(field23),sum(field24),sum(field25) from reptable
GO
