CREATE TRIGGER [dbo].[Commmision_insert]
ON [dbo].[Commmision]
AFTER INSERT
AS
		declare @buyid int 
		declare @houseid int
		declare @paidmoney decimal(18,2)
		select @buyid=buyid,@paidmoney=paidmoney from inserted
		select @houseid=hourseid from buyhourse where buyid=@buyid
		update hourseinfo set commisionpaid=commisionpaid+@paidmoney where hourseId=@houseid

GO
