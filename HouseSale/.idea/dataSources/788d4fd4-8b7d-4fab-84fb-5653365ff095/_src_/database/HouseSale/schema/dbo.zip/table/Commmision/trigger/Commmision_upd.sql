CREATE TRIGGER [dbo].[Commmision_upd]
ON [dbo].[Commmision]
AFTER UPDATE
AS
		declare @buyid int 
		declare @houseid int
		declare @paidmoney decimal(18,2)
		select @buyid=buyid,@paidmoney=paidmoney from inserted
		select @houseid=hourseid from buyhourse where buyid=@buyid
		update hourseinfo set commisionpaid=commisionpaid-@paidmoney where hourseId=@houseid

GO
