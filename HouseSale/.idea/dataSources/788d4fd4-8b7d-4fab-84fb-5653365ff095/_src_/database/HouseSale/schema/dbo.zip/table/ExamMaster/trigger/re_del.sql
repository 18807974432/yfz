CREATE TRIGGER [dbo].[re_del]
ON [dbo].[ExamMaster]
AFTER DELETE
AS

	declare  @cnt int 
	declare @researchid int 
	select @researchid=reseachid from deleted
	select @cnt = count(examid) from exammaster where reseachid=@researchid
	update researchExam set examCount=@cnt where  reseachid=@researchid

GO
